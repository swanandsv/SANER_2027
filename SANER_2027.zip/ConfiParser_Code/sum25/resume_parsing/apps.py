from django.apps import AppConfig


class ResumeParsingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'resume_parsing'
