from django.shortcuts import render
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage
import os, json, base64, tempfile, requests
from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import default_storage
import os
import base64
import json
import tempfile
import threading
import requests
from django.urls import reverse
from django.http import HttpRequest
from openai import OpenAI
from django.contrib.sessions.models import Session
from django.contrib.sessions.backends.db import SessionStore
from PyPDF2 import PdfReader
from docx import Document
import time
from pdfminer.high_level import extract_text as extract_pdf_text
import re
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt


ALLOWED_EXTENSIONS = ['.pdf', '.doc', '.docx']
api_key = "Enter your GPT-4 API Key"
client = OpenAI(api_key=api_key)

JOB_DESCRIPTIONS = {
    "Software Engineering": "<h1>Web Developer Remote </h1><h1> Call / Send Your Resume On HR Team +917017750146</h1><h2>Benefits</h2><ul><li>Flexible working hours</li><li>Competitive compensation package</li><li>Opportunity to expand your skills and knowledge</li><li>Friendly and supportive team environment</li><li>Chance to work on exciting projects for reputable brands</li></ul><h2>Daily Tasks</h2><ul><li>Develop websites according to client requirements and specifications</li><li>Ensure website functionality and performance</li><li>Maintain and update websites as needed</li><li>Create and maintain software documentation</li><li>Collaborate with team members to troubleshoot and solve technical issues</li></ul><h2>Requirements</h2><ul><li>Solid experience in web development</li><li>Expertise in HTML, CSS, and JavaScript</li><li>Fluent in web programming languages such as PHP, Ruby, or Python</li><li>Experience in cross-platform development</li><li>Ability to work independently and collaboratively</li></ul><h2>Additional Skills</h2><ul><li>Experience with content management systems such as WordPress or Joomla</li><li>Understanding of SEO principles</li><li>Knowledge of web security protocols</li><li>Experience with front-end frameworks such as React or Vue.js</li><li>Strong communication skills</li></ul>",
    "Mechanical Engineering": "Design and analyze mechanical systems...",
    "Accountant": "Manage financial records, prepare reports, ensure compliance...",
    "Construction Management": "Oversee construction projects, manage teams and budgets..."
}

#def llm_rating_status(request):
    #return JsonResponse({"ready": "llm_rating_result" in request.session})

def check_gpt_status(request):
    session_key = request.session.session_key
    session = SessionStore(session_key=session_key)
    #print(f"[CHECK STATUS] Checking session key: {session_key}")
    gpt_data_exists = 'gpt_parsed_resume' in session

    #print(f"[CHECK STATUS] GPT session data: {gpt_data_exists}")
    return JsonResponse({'ready': gpt_data_exists})


def clean_json_string(gpt_output: str) -> str:
    # Remove triple backticks and any language hint like ```json
    return re.sub(r"^```json\s*|\s*```$", "", gpt_output.strip(), flags=re.IGNORECASE | re.MULTILINE)


def extract_text_from_file(file_path: str, ext: str) -> str:
    try:
        if ext == '.pdf':
            return extract_pdf_text(file_path)
        elif ext in ['.doc', '.docx']:
            doc = Document(file_path)
            return "\n".join([para.text for para in doc.paragraphs])
        else:
            return ""
    except Exception as e:
        #print(f"Error extracting text: {e}")
        return ""

def gpt_parse_resume(text_content: str, session_key: str):
    #print(f"[THREAD-{threading.get_ident()}] LLM parsing thread started.")
    #print(f"[THREAD-{threading.get_ident()}] Sending request to OpenAI...")

   
    prompt = (
    "You are an expert resume parser. From the resume text below, return ONLY a valid JSON object\n"
    "with the following structure (no extra keys, no markdown):\n\n"

    "{\n"
    "  \"Name\": { \"value\": \"<full name>\", \"confidence\": <0-10> },\n"
    "  \"Email\": { \"value\": \"<email address>\", \"confidence\": <0-10> },\n"
    "  \"Websites\": { \"value\": [\"<url1>\", \"<url2>\", …], \"confidence\": <0-10> },\n\n"

    "  \"Education\": [\n"
    "    {\n"
    "      \"University name\": \"<university>\",\n"
    "      \"location\": \"<city, state / country>\",\n"
    "      \"major\": \"<major or degree>\",\n"
    "      \"start date\": \"<MMM YYYY or YYYY or null>\",\n"
    "      \"end date\": \"<MMM YYYY or YYYY or null>\",\n"
    "      \"GPA\": \"<gpa or null>\",\n"
    "      \"confidence\": <0-10>\n"
    "    }\n"
    "  ],\n\n"

    "  \"WorkExperience\": [\n"
    "    {\n"
    "      \"company name\": \"<company>\",\n"
    "      \"company_confidence\": <0-10>\n"
    "      \"job title\": \"<title>\",\n"
    "      \"title_confidence\": <0-10>\n"
    "      \"period\": \"<start – end>\",\n"
    "    }\n"
    "  ],\n\n"

    "  \"Skills\": [\n"
    "    {\n"
    "     \"skills\": [\"<skill1>\", \"<skill2>\", …],\n"
    "  ],\n\n"

    "  \"Certifications\": { \"value\": [\"<cert1>\", \"<cert2>\", …], \"confidence\": <0-10> },\n\n"

    "  \"Publications\": [\n"
    "    {\n"
    "      \"title\": \"<paper title>\",\n"
    "      \"authors\": \"<author list>\",\n"
    "      \"conference\": \"<journal or conference>\",\n"
    "      \"confidence\": <0-10>\n"
    "    }\n"
    "  ]\n"
    "}\n\n"

    "Rules:\n"
    "- All confidence scores must be integers from 0 to 10.\n"
    "- Use null where a field is missing.\n"
    "- Do NOT wrap the JSON in triple backticks or include any explanation.\n"
    "- Follow the field names and nesting exactly as specified.\n\n"

    f"Resume:\n{text_content}"
)
    

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            temperature=0,
            messages=[
                {"role": "system", "content": "You are an expert resume parser."},
                {"role": "user", "content": prompt}
            ]
        )

        raw_output = response.choices[0].message.content.strip()
        #print(f"[THREAD-{threading.get_ident()}] Raw GPT response: {repr(raw_output)}")

        cleaned_output = clean_json_string(raw_output)

        try:
            parsed_data = json.loads(cleaned_output)
        except json.JSONDecodeError as e:
            #print(f"[THREAD-{threading.get_ident()}] JSON decode error: {e}")
            parsed_data = {"error": str(e), "raw": cleaned_output}

    except Exception as e:
        #print(f"[THREAD-{threading.get_ident()}] GPT request failed: {e}")
        parsed_data = {"error": str(e)}

    try:
        session = SessionStore(session_key=session_key)
        print(parsed_data)
        session['gpt_parsed_resume'] = parsed_data
        session.save()
        #print(f"[THREAD-] Session data saved successfully.")
    except Exception as e:
        #print(f"[THREAD] Error saving session: {e}")
        pass

    #print(f"[THREAD] LLM parsing thread finished.")
    #print(f"[THREAD-{threading.get_ident()}] Saving to session key: {session_key}")

@csrf_exempt
def llm_rating_process(request):
    if request.method != "POST":
        return JsonResponse({"error": "POST required"}, status=405)

    session_key = request.POST.get("session_key") or request.session.session_key
    if not session_key:
        return JsonResponse({"error": "Missing session key"}, status=400)

    session = SessionStore(session_key=session_key)
    job_description = session.get("job_description", "")
    resume_data = session.get("gpt_parsed_resume", {})

    if not job_description or not resume_data:
        return JsonResponse({"error": "Missing session data"}, status=400)

    prompt = f"""
You are a professional job recruiter. You will be provided with two pieces of information:

1. A job description (JD)
2. A parsed resume with structured fields (Resume)

Your task is to extract the requirements for the following four categories from the job description:
- Work Experience
- Skills
- Education
- Certifications

Then, rate the resume's alignment with the job description in these four categories on a scale from 0 to 5.

Format your answer in valid JSON with this structure:

{{
  "Requirements": {{
    "WorkExperience": "<list or summary>",
    "Skills": "<list or summary>",
    "Education": "<summary>",
    "Certifications": "<list or summary>"
  }},
  "Ratings": {{
    "WorkExperience": {{
      "score": <0-5>,
      "reason": "<why this score was assigned>"
    }},
    "Skills": {{
      "score": <0-5>,
      "reason": "<why this score was assigned>"
    }},
    "Education": {{
      "score": <0-5>,
      "reason": "<why this score was assigned>"
    }},
    "Certifications": {{
      "score": <0-5>,
      "reason": "<why this score was assigned>"
    }}
  }}
}}

Job Description (JD):
{job_description}

Resume:
{json.dumps(resume_data, indent=2)}
    """


    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            temperature=0,
            messages=[
                {"role": "system", "content": "You are a resume evaluation expert."},
                {"role": "user", "content": prompt}
            ]
        )

        content = response.choices[0].message.content.strip()
        cleaned = clean_json_string(content)
        result = json.loads(cleaned)

        session["llm_rating_result"] = result
        session.save()

        # Instead of returning JSON, redirect to result page
        return redirect('llm_rating')

    except Exception as e:
        session["llm_rating_result"] = {"error": str(e)}
        session.save()
        # Show error on the rating page
        return redirect('llm_rating')




def home(request):
    for key in ("parsed_resume", "gpt_parsed_resume"):
        request.session.pop(key, None)   # discard if present
    return render(request, "home.html", {"jobs": JOB_DESCRIPTIONS.keys()})

def job_detail(request):
    description = JOB_DESCRIPTIONS.get("No description available.")
    return render(request, 'job_detail.html', {'description': description})

def apply_job(request: HttpRequest):
    if request.method == 'POST' and request.FILES.get('resume_file'):
        uploaded_file = request.FILES['resume_file']
        file_name = uploaded_file.name
        ext = os.path.splitext(file_name)[1].lower()

        if ext not in ALLOWED_EXTENSIONS:
            return render(request, 'job_detail.html', {'error': 'Only PDF, DOC, or DOCX files are allowed.'})

                job_description = request.POST.get('job_description', '').strip()
        if not job_description:
            return render(request, 'job_detail.html', {'error': 'Please paste a job description.'})

                request.session['job_description'] = job_description

        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, dir=settings.MEDIA_ROOT, suffix=ext) as temp_file:
            for chunk in uploaded_file.chunks():
                temp_file.write(chunk)
            temp_file_path = temp_file.name

        # Extract resume text
        resume_text = extract_text_from_file(temp_file_path, ext)

        # Read file content for encoding
        with open(temp_file_path, 'rb') as f:
            raw_content = f.read()
            encoded_string = base64.b64encode(raw_content).decode('utf-8')

        # Ensure session exists
        if not request.session.session_key:
            request.session.save()

        session_key = request.session.session_key

        # Background GPT-4 parsing thread with job_description
        thread = threading.Thread(target=gpt_parse_resume, args=(resume_text, session_key))
        thread.start()

        # RChilli API call
        APIURL = "Enter Rchilli API Key"
        USERKEY = 'OWBDJ18A'
        VERSION = '8.0.0'
        SUBUSER_ID = 'Enter Rchilli SubUser ID'

        body = {
            "filedata": encoded_string,
            "filename": file_name,
            "userkey": USERKEY,
            "version": VERSION,
            "subuserid": SUBUSER_ID
        }

        headers = {'Content-Type': 'application/json'}
        response = requests.post(APIURL, data=json.dumps(body), headers=headers)
        
        # Clean up temp file
        os.remove(temp_file_path)

        # Process RChilli response
        if response.status_code == 200:
            data = response.json().get("ResumeParserData", {})

            request.session['parsed_resume'] = data
            return redirect('resume_result')
        else:
            return render(request, 'job_detail.html', {'error': 'Resume parsing failed. Please try again.'})

    return render(request, 'job_detail.html', {})

def resume_result(request):
    data = request.session.get('parsed_resume')
    return render(request, 'resume_result.html', {'data': data})

def llm_parsing(request):
    data = request.session.get('gpt_parsed_resume')
    if not data:
        return render(request, 'llm_parsing.html', {'error': 'GPT parsing still in progress. Please try again later.'})
    return render(request, 'llm_parsing.html', {'data': data})

def llm_rating(request):
    result = request.session.get("llm_rating_result")
    if not result:
        return render(request, "llm_rating.html", {"error": "Rating not available yet."})
    return render(request, "llm_rating.html", {"result": result})


