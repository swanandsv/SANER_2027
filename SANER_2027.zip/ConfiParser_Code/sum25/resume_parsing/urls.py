from . import views
from django.urls import path 

urlpatterns = [
    path('', views.home, name='home'),
    path('job/', views.job_detail, name='job_detail'),
    path('apply/', views.apply_job, name='apply_job'),
    path('result/', views.resume_result, name='resume_result'),
    path('llm-parsing/', views.llm_parsing, name='llm_parsing'),
    path("llm_rating/", views.llm_rating, name="llm_rating"),
    path("llm_rating_process/", views.llm_rating_process, name="llm_rating_process"),
    #path("llm_rating_status/", views.llm_rating_status, name="llm_rating_status"),
    path('check-gpt-status/', views.check_gpt_status, name='check_gpt_status'),
]