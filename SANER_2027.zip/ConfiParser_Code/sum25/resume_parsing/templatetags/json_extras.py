from django import template
register = template.Library()

@register.filter
def get_item(obj, key):
    """
    Template helper: return obj[key] even when the key contains spaces.
    Usage: {{ mydict|get_item:"Some Key" }}
    """
    try:
        return obj.get(key)
    except (AttributeError, TypeError):
        return ""
