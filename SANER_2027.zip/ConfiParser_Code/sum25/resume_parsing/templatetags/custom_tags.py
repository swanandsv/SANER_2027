from django import template
from django.utils.safestring import mark_safe

register = template.Library()

@register.filter
def render_stars(score):
    """Converts 0–10 score to star icons safely"""
    try:
        score = int(score)
    except (ValueError, TypeError):
        return mark_safe("☆☆☆☆☆☆☆☆☆☆")  # All empty
    stars = "★" * score + "☆" * (10 - score)
    return mark_safe(stars)  # <-- THIS IS CRITICAL